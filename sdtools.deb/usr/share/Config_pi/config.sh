#!/bin/bash

echo "test ok"
